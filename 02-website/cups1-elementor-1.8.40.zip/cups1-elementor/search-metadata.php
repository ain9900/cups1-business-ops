<?php

namespace Cups1\ElementorSite;

defined( 'ABSPATH' ) || exit;

function search_description(): string {
	$slug = get_post_meta( get_queried_object_id(), '_cups1_component_page', true );
	$descriptions = [
		'home' => 'Source custom-printed paper cups, food bowls, and takeaway packaging for cafés, restaurants, and distributors. Request a delivered quote for the US or Canada.',
		'products' => 'Explore Cups1 packaging for beverages, desserts, and takeaway. Compare formats and request a quote for the product you need.',
		'customize' => 'Choose a packaging format and share your dimensions, branding, quantity, and artwork for a custom quote from Cups1.',
		'custom-printing' => 'See how Cups1 coordinates logo placement, brand colors, artwork preparation, and proof review for custom packaging.',
		'how-it-works' => 'Learn how to request a packaging quote, review your artwork proof, and coordinate production and delivery with Cups1.',
		'industries' => 'Explore custom packaging options for cafés, restaurant groups, and wholesale buyers in the US and Canada.',
		'documents' => 'Ask Cups1 about product specifications, available reports, and inspection records for your packaging and destination.',
		'about' => 'Learn how Cups1 coordinates supplier sourcing, artwork proofs, quality review, and cross-border delivery for custom packaging.',
		'faq' => 'Find answers about custom packaging, artwork, order minimums, samples, delivery, and product documentation.',
		'shipping-delivery' => 'See what goes into a Cups1 delivered quote, including setup, freight, applicable duties, and destination delivery.',
		'request-a-quote' => 'Request a delivered quote for custom paper cups or food packaging. Share the product, order quantity, destination, and artwork if available.',
		'request-a-sample' => 'Request a Cups1 sample kit to compare packaging formats, materials, and fit before placing a custom order.',
		'contact' => 'Contact Cups1 with questions about custom packaging, artwork, delivery, or product documentation.',
		'for-distributors' => 'Discuss custom packaging sourcing and delivery options for a wholesale project or a recurring supply program.',
		'resources' => 'Find buyer guides to Cups1 custom printing, delivered quote costs, and common packaging questions.',
	];
	if ( isset( $descriptions[ $slug ] ) ) {
		return $descriptions[ $slug ];
	}
	if ( isset( design()['pages'][ $slug ] ) ) {
		return sprintf( 'Explore %s from Cups1. Ask about size, custom printing, samples, and delivered quotes for the US and Canada.', get_the_title() );
	}
	return '';
}

add_action( 'wp_head', function () {
	if ( ! uses_design() || ! is_page() ) {
		return;
	}
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( asset_url( 'favicon.svg' ) ) . '">' . "\n";
	}
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) ) {
		return;
	}
	$description = search_description();
	if ( $description ) {
		echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
	}
}, 5 );

add_filter( 'document_title_parts', function ( array $parts ): array {
	if ( is_front_page() && uses_design() ) {
		$parts['tagline'] = 'Custom Branded Cups & Food Packaging';
	}
	return $parts;
} );

add_filter( 'wp_robots', function ( array $robots ): array {
	if ( uses_design() && isset( $_GET['inquiry'] ) ) {
		$robots['noindex'] = true;
	}
	return $robots;
} );
