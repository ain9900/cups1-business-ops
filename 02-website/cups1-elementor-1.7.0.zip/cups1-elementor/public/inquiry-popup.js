(() => {
  const popup = document.querySelector("[data-inquiry-popup]");
  if (!popup || typeof popup.showModal !== "function" || !window.crypto?.getRandomValues) return;

  const form = popup.querySelector("form");
  const contact = form.querySelector('[data-popup-step="contact"]');
  const details = form.querySelector('[data-popup-step="details"]');
  const status = form.querySelector("[data-popup-status]");
  const advance = form.querySelector('button[type="submit"]');
  const close = popup.querySelector(".cups1-popup-close");
  const routes = {
    "request-a-quote": "quote",
    "request-a-sample": "sample",
    "contact-sales": "contact",
    "configure-packaging": "customize",
  };
  let trigger;
  let context;
  let step;
  let busy = false;

  document.addEventListener("click", (event) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest("a[href]");
    if (!link || link.target && link.target !== "_self" || link.hasAttribute("download")) return;
    const url = new URL(link.href);
    if (url.origin !== location.origin) return;
    const route = url.pathname.split("/").filter(Boolean).pop();
    const homeInquiry = url.pathname === "/" && url.hash === "#quote";
    const reason = link.dataset.inquiryReason || routes[route] || (homeInquiry ? url.searchParams.get("intent") || "quote" : "");
    if (!reason || !Array.from(form.elements.reason.options).some((option) => option.value === reason)) return;
    event.preventDefault();
    trigger = link;
    form.reset();
    step = "contact";
    status.textContent = "";
    contact.hidden = contact.disabled = false;
    details.hidden = details.disabled = true;
    advance.hidden = false;
    advance.textContent = "Next";
    form.elements.reason.value = reason;
    const product = url.searchParams.get("packaging_product") || url.searchParams.get("product") || "";
    const sizePicker = link.closest(".catalog-product-card, [data-product-detail]")?.querySelector("[data-catalog-quote-size]");
    const size = sizePicker?.value || url.searchParams.get("packaging_size") || "";
    context = {
      product,
      size,
      token: Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, "0")).join(""),
    };
    popup.showModal();
  });

  close.addEventListener("click", () => { if (!busy) popup.close(); });
  popup.addEventListener("cancel", (event) => { if (busy) event.preventDefault(); });
  popup.addEventListener("close", () => trigger?.focus());

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (busy || step === "complete") return;
    busy = close.disabled = advance.disabled = true;
    status.textContent = "Saving…";
    const data = new FormData(form);
    data.set("action", "cups1_inquiry_step");
    data.set("step", step);
    data.set("token", context.token);
    if (step === "contact") {
      data.set("product", context.product);
      data.set("selected_size", context.size);
    }
    try {
      const tokenURL = new URL(form.action);
      tokenURL.searchParams.set("action", "cups1_form_token");
      const tokenResponse = await fetch(tokenURL, { cache: "no-store", credentials: "same-origin" });
      const token = await tokenResponse.json();
      if (!token.success || !token.data.nonce) throw new Error();
      data.set("cups1_nonce", token.data.nonce);
      const response = await fetch(form.action, { method: "POST", body: data, credentials: "same-origin" });
      const result = await response.json();
      if (!result.success) {
        status.textContent = result.data?.message || "Could not save. Please try again.";
        return;
      }
      if (step === "contact") {
        step = "details";
        const reason = data.get("reason");
        contact.hidden = contact.disabled = true;
        details.hidden = details.disabled = false;
        details.querySelectorAll("[data-reasons]").forEach((label) => {
          label.hidden = !label.dataset.reasons.split(" ").includes(reason);
          label.querySelector("input, select").disabled = label.hidden;
        });
        form.elements.product.value = context.product;
        form.elements.dimensions.value = context.size;
        form.elements.notes.required = reason === "contact";
        advance.textContent = "Done";
        status.textContent = "Contact details saved.";
        details.querySelector(":is(input, select, textarea):enabled")?.focus();
      } else {
        step = "complete";
        details.hidden = details.disabled = true;
        advance.hidden = true;
        status.textContent = "Your inquiry was received. Reference: " + result.data.reference + ".";
        close.disabled = false;
        close.focus();
      }
    } catch {
      status.textContent = "Could not confirm the save. Please try again.";
    } finally {
      busy = close.disabled = advance.disabled = false;
    }
  });
})();
