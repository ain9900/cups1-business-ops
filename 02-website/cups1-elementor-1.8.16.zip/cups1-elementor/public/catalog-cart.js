/* global cups1CatalogCart, jQuery */
(() => {
  function init() {
    const cartButtons = document.querySelectorAll('[data-catalog-cart-item]');
    if (!cartButtons.length || !window.jQuery) return;

    const dialog = document.createElement('dialog');
    dialog.className = 'cups1-catalog-cart';
    dialog.setAttribute('aria-labelledby', 'cups1-cart-heading');
    dialog.innerHTML = '<h2 id="cups1-cart-heading">Your cart</h2><p role="status"></p><ul></ul><p data-total></p><form method="dialog"><button class="button outline">Continue shopping</button></form>';
    document.body.append(dialog);
    const status = dialog.querySelector('[role=status]');
    const list = dialog.querySelector('ul');
    const total = dialog.querySelector('[data-total]');
    const open = document.createElement('button');
    open.type = 'button';
    open.className = 'button outline cups1-cart-open';
    open.textContent = 'View cart';
    const detailActions = document.querySelector('[data-product-detail] .product-details .actions:has([data-catalog-cart-item])');
    const grid = document.querySelector('.catalog-grid:has([data-catalog-cart-item])');
    (detailActions || grid).before(open);

    const endpoint = cups1CatalogCart.endpoint;
    let nonce;
    async function request(action = '', body) {
      if (body && !nonce) await request();
      const response = await fetch(endpoint + action, {
        credentials: 'same-origin', cache: 'no-store', method: body ? 'POST' : 'GET',
        headers: body ? { 'Content-Type': 'application/json', Nonce: nonce || '' } : {},
        body: body ? JSON.stringify(body) : undefined
      });
      nonce = response.headers.get('Nonce') || nonce;
      const cart = await response.json();
      if (!response.ok) throw new Error(cart.message || 'WooCommerce could not update your cart.');
      return cart;
    }

    function render(cart) {
      open.textContent = 'View cart (' + cart.items_count + ')';
      list.replaceChildren();
      cart.items.forEach((item) => {
        const row = document.createElement('li');
        const options = item.variation.map((option) => option.value).join(', ');
        row.textContent = item.name + (options ? ' · ' + options : '') + ' × ' + item.quantity;
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.textContent = 'Remove';
        remove.setAttribute('aria-label', 'Remove ' + item.name + (options ? ' ' + options : ''));
        remove.addEventListener('click', () => showCart('/remove-item', { key: item.key }));
        row.append(remove);
        list.append(row);
      });
      const t = cart.totals;
      const amount = Number(t.total_items) / 10 ** t.currency_minor_unit;
      total.textContent = cart.items.length ? 'Subtotal ' + new Intl.NumberFormat(undefined, { style: 'currency', currency: t.currency_code }).format(amount) : 'Your cart is empty.';
    }

    let busy = false;
    async function showCart(action = '', body, trigger) {
      if (busy) return;
      busy = true;
      if (trigger) trigger.disabled = true;
      if (!dialog.open) dialog.showModal();
      status.textContent = 'Updating cart…';
      try {
        render(await request(action, body));
        status.textContent = action === '/add-item' ? 'Added to your cart.' : '';
      } catch (error) {
        status.textContent = error.message || 'Cart is unavailable. Please try again.';
      } finally {
        busy = false;
        if (trigger) trigger.disabled = !trigger.dataset.cartId;
      }
    }
    open.addEventListener('click', () => showCart());

    cartButtons.forEach((button) => {
      if (button.hasAttribute('data-catalog-unavailable')) return;
      const product = button.closest('.catalog-product-card, [data-product-detail]');
      const form = product.querySelector('.variations_form');
      if (form) {
        function setVariation(variation, purchasable) {
          button.dataset.cartId = purchasable ? variation.variation_id : '';
          button.disabled = !button.dataset.cartId;
        }
        jQuery(form).on('show_variation', (_event, variation, purchasable) => setVariation(variation, purchasable));
        jQuery(form).on('hide_variation reset_data', () => setVariation(null, false));
        form.addEventListener('change', (event) => {
          if (event.target.matches('.variations select')) setVariation(null, false);
        }, true);
      } else {
        button.dataset.cartId = button.dataset.catalogCartItem;
      }
      button.addEventListener('click', () => {
        const id = Number(button.dataset.cartId);
        if (!id) return;
        const variation = form ? [...form.querySelectorAll('.variations select')].map((select) => ({
          attribute: select.name,
          value: select.value
        })) : [];
        showCart('/add-item', { id, quantity: 1, variation }, button);
      });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();

(() => {
  function initAvailabilityLabels() {
    const $ = window.jQuery;
    if (!$) return;
    document.querySelectorAll('.catalog-grid .catalog-product-card .variations_form').forEach((form) => {
      if (form.dataset.cups1AvailabilityLabels) return;
      form.dataset.cups1AvailabilityLabels = 'true';
      const selects = [...form.querySelectorAll('.variations select')];
      const initialOptions = new Map(selects.map((select) => [select, [...select.options].map((option) => option.cloneNode(true))]));
      function refresh() {
        const variations = $(form).data('product_variations');
        if (!Array.isArray(variations)) return;
        selects.forEach((select) => {
          const reference = $(select).data('attribute_options') || initialOptions.get(select);
          const current = new Map([...select.options].map((option) => [option.value, option]));
          const matchesOtherChoices = (variation) => selects.every((other) => {
            const value = variation.attributes[other.name];
            return other === select || !other.value || !value || other.value === value;
          });
          let next = null;
          [...reference].reverse().forEach((original) => {
            const value = original.value;
            if (!value) return;
            const matches = variations.filter((variation) => matchesOtherChoices(variation) &&
              (!variation.attributes[select.name] || variation.attributes[select.name] === value));
            const outOfStock = matches.length > 0 && matches.every((variation) => !variation.is_in_stock);
            let option = current.get(value);
            if (!option) {
              option = new Option(original.textContent, value);
              option.disabled = true;
              select.insertBefore(option, next);
            }
            if (outOfStock) option.disabled = true;
            const label = original.textContent.trim();
            option.textContent = label + (outOfStock ? ' (Out of stock)' : option.disabled ? ' (Unavailable)' : '');
            next = option;
          });
        });
      }
      $(form).on('woocommerce_update_variation_values.cups1Availability', refresh);
      refresh();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAvailabilityLabels, { once: true });
  else initAvailabilityLabels();
})();
