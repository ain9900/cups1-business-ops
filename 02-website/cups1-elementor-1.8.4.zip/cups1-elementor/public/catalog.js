/* global jQuery */
document.querySelectorAll(".cups1-variation-purchase").forEach((purchase) => {
  const form = purchase.querySelector(".variations_form");
  if (!form) return;

  const price = purchase.querySelector("[data-catalog-price]");
  const caseLabel = purchase.querySelector("[data-catalog-case]");
  const stock = purchase.querySelector("[data-catalog-stock]");
  const initialPrice = price.innerHTML;
  const initialCase = caseLabel.textContent;
  const card = purchase.closest(".catalog-product-card");
  const product = purchase.closest("[data-product-detail]");
  const links = card?.querySelectorAll("[data-catalog-product-link]") ?? [];
  const customize = card?.querySelector("[data-catalog-quote-link]");
  const image = card?.querySelector("[data-catalog-product-link] img") ?? product?.querySelector("#gallery-image");
  const caption = product?.querySelector("#gallery-caption");
  const attributes = ["src", "srcset", "sizes", "alt"];
  let previousImage;
  let previousCaption;
  let previousThumbnail;

  function updateImage(variationImage) {
    if (!image) return;
    if (variationImage?.src) {
      if (!previousImage) {
        previousImage = attributes.map((name) => image.getAttribute(name));
        previousCaption = caption?.textContent;
        previousThumbnail = product?.querySelector('.gallery-controls [aria-pressed="true"]');
      }
      attributes.forEach((name) => {
        if (variationImage[name] || name === "alt") image.setAttribute(name, variationImage[name] ?? "");
        else image.removeAttribute(name);
      });
      product?.querySelector('.gallery-controls [aria-pressed="true"]')?.setAttribute("aria-pressed", "false");
      if (caption) caption.textContent = variationImage.title || "";
    } else if (previousImage) {
      attributes.forEach((name, index) => {
        const value = previousImage[index];
        if (value === null) image.removeAttribute(name);
        else image.setAttribute(name, value);
      });
      if (caption) caption.textContent = previousCaption;
      previousThumbnail?.setAttribute("aria-pressed", "true");
      previousImage = null;
    }
  }

  function updateSummary(variation) {
    price.innerHTML = variation?.cups1_price_html || initialPrice;
    caseLabel.textContent = variation?.cups1_case_label ?? initialCase;
    caseLabel.hidden = !caseLabel.textContent;
    stock.textContent = variation?.cups1_stock_label || "";
    stock.hidden = !stock.textContent;
    updateImage(variation?.image);
  }

  function updateProductLinks() {
    const options = form.querySelectorAll(".variations select");
    if (customize) {
      const destination = new URL(customize.href);
      const size = form.querySelector('select[name="attribute_size"], select[name="attribute_pa_size"]');
      if (size?.value) destination.searchParams.set("packaging_size", size.value);
      else destination.searchParams.delete("packaging_size");
      customize.href = destination.href;
    }
    links.forEach((link) => {
      const destination = new URL(link.href);
      options.forEach(({ name, value }) => {
        if (value) destination.searchParams.set(name, value);
        else destination.searchParams.delete(name);
      });
      link.href = destination.href;
    });
  }

  product?.querySelector(".gallery-controls")?.addEventListener("click", (event) => {
    if (event.target.closest("button[data-image]")) previousImage = null;
  });
  form.addEventListener("change", (event) => {
    if (event.target.matches(".variations select")) {
      updateSummary();
      updateProductLinks();
    }
  }, true);
  jQuery(form).on("show_variation", (_event, variation) => updateSummary(variation));
  jQuery(form).on("hide_variation reset_data", () => updateSummary());
  jQuery(form).on("woocommerce_variation_has_changed", updateProductLinks);
  updateProductLinks();
});
